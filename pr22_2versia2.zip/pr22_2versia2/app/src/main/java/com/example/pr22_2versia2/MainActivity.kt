package com.example.pr22_2versia2

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.support.v7.app.AlertDialog
import android.widget.Button
import android.widget.EditText

class MainActivity : AppCompatActivity() {
    private lateinit var usernameEditText: EditText
    private lateinit var passwordEditText: EditText
    private lateinit var sharedPreferences: SharedPreferences
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val registerButton = findViewById<Button>(R.id.registrbut)
        registerButton.setOnClickListener {
            val intent = Intent(this, RegistrActivity::class.java)
            startActivity(intent)
            finish()
        }
        usernameEditText = findViewById(R.id.login)
        passwordEditText = findViewById(R.id.pass)
        val loginButton: Button = findViewById(R.id.enterbut)
        sharedPreferences = getSharedPreferences("my_app_prefs", Context.MODE_PRIVATE)

        // загрузка сохраненного имя пользователя и пароля из SharedPreferences
        val savedUsername = sharedPreferences.getString("login", "")
        val savedPassword = sharedPreferences.getString("password", "")
        // установка сохраненного имя пользователя в EditText
        usernameEditText.setText(savedUsername)

        loginButton.setOnClickListener {
            val username = usernameEditText.text.toString().trim()
            val password = passwordEditText.text.toString().trim()

            if (username.isEmpty()) {
                usernameEditText.error = "Пожалуйста, введите имя пользователя"
                if (password.isEmpty()) {
                    passwordEditText.error = "Пожалуйста, введите пароль"
                    return@setOnClickListener
                }
                return@setOnClickListener
            }
            if (password.isEmpty()) {
                passwordEditText.error = "Пожалуйста, введите пароль"
                return@setOnClickListener
            }

            if (savedUsername == username && savedPassword == password) {
                val intent = Intent(this, PokemonActivity::class.java)
                intent.putExtra("saved_username", username)
                startActivity(intent)
                finish()
            } else {
                val alertDialogBuilder = AlertDialog.Builder(this)
                alertDialogBuilder.setTitle("Ошибка")
                alertDialogBuilder.setMessage("Неверный логин или пароль.")
                alertDialogBuilder.setPositiveButton("OK") { _, _ -> }
                val alertDialog = alertDialogBuilder.create()
                alertDialog.show()
            }
        }
    }
}